import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.Assert;

public class RegistrationFormTest2{
       public WebDriver driver;
       @BeforeMethod
       public void setup(){
           System.setProperty("webdriver.chrome.driver","E:\\ChromeDrivers\\chromedriver-win32\\chromedriver.exe");
           driver = new ChromeDriver();
       //navigate to url
       driver.get("https://qaregform.ccbp.tech/");
       }
       @AfterMethod
       public void tearDown(){
           driver.quit();
       }
       @Test(priority = 1)
       public void testRegistrationWithemptyInputs(){
       //button
           WebElement buttonEl = driver.findElement(By.cssSelector("button.submit-button"));
           buttonEl.click();
           //first input
           WebElement firstinput = driver.findElement(By.xpath("/html/body/div/div/div/form/p[1]"));
           String actualText = firstinput.getText();
           //assert
           Assert.assertEquals(actualText,"Required","Error text with empty input field do not match");
           //secondinput
           WebElement secondinput = driver.findElement(By.xpath("/html/body/div/div/div/form/p[2]"));
           actualText =secondinput.getText();
           Assert.assertEquals(actualText,"Required","Error text with empty input field do not match");
       }
       @Test(priority = 2)
        public void TestRegistrationWithLastName(){
           WebElement secondinput = driver.findElement(By.xpath("/html/body/div/div/div/form/div[2]/input"));
           secondinput.sendKeys("Doe");
           //button
           WebElement buttonEl = driver.findElement(By.cssSelector("button.submit-button"));
           buttonEl.click();
           //firstname
           WebElement firstnameEl = driver.findElement(By.xpath("/html/body/div/div/div/form/p"));
           String actualtext = firstnameEl.getText();
           //assert
           Assert.assertEquals(actualtext,"Required","Error text at first name do not match");
       }

       @Test(priority = 3)
       public void TestRegistrationWithFirstName(){
           WebElement firstname = driver.findElement(By.cssSelector("input#firstName"));
           firstname.sendKeys("John");
           //button
           WebElement buttonEl = driver.findElement(By.cssSelector("button.submit-button"));
           buttonEl.click();
           //second input
           WebElement secondinput = driver.findElement(By.xpath("/html/body/div/div/div/form/p"));
           String actualtext = secondinput.getText();
           //assert
           Assert.assertEquals(actualtext,"Required","Error text at last name do not match");
       }

       @Test(priority = 4)
       public void inputFields(){
           WebElement firstinput = driver.findElement(By.cssSelector("input#firstName"));
           firstinput.sendKeys("John");
           //secondinput
           WebElement secondinput = driver.findElement(By.xpath("/html/body/div/div/div/form/div[2]/input"));
           secondinput.sendKeys("Doe");
           //button
           WebElement buttonEl = driver.findElement(By.cssSelector("button.submit-button"));
           buttonEl.click();
           //wait
           WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
           wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/div/div/img")));
           //successmsg
           WebElement successMsg = driver.findElement(By.xpath("/html/body/div/div/div/p"));
           String actualMsg = successMsg.getText();
           //assert
           Assert.assertEquals(actualMsg,"Submitted Successfully","Success message do not match");
       }

}
